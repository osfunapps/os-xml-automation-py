import os_file_automation.xml_mapper.xml_mapper as xm

xm.set_texts_by_xml('/Users/home/Programming/Python/projects/PrepeareGeneralRemoteiOS/src/ads/normalize/normal_ads_props.xml',
                    {'$project_path': '/Users/home/Programming/iOS/Remotes/Projects/GeneralRemote/GeneralRemoteiOS'})
